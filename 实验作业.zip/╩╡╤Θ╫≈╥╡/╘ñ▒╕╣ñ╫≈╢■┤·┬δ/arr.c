int main() {
    int arr[10];
    int i  = 0;
    for (; i < 10; i ++) arr[i] = i;
    return 0;
}