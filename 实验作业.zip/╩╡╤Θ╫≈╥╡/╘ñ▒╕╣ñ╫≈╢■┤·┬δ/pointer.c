    int main() {
        int c = 3;
        int* p1 = &c;
        return 0;
    }