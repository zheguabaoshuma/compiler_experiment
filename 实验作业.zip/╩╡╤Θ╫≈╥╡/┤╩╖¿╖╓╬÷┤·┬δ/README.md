# 2022lab4-Skeleton
For 2022Fall NKUCS Course - Principle of Compilers Lab4

> Author: Emanual20
> 
> Date: 2021/10/16

目前使用方式：

- make testlabfour: 编译lexer.l，测试test/lab4下所有sy文件。注意需要解注释ONLY_FOR_LEX宏定义，测试文件要以sy结尾。
- make cleanlabfour: 清理编译出的二进制文件及测试结果。

目前只给出了lexer.l的框架，parser.y, SymbolTable.\[cpp|h\], Ast.\[cpp|h\], Type.\[cpp|h\] 在下次给出。

学有余力的同学，鼓励一次性完成语法分析(框架见lab5分支)，对理解该过程更具有连贯性。 
